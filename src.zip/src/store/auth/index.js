import authReducer from './auth.reducer';

export * from './auth.actions';
export default authReducer;
