export const submitUser = function ({ email, password }, onSuccess, onFail) {
    console.log('SUBMIT', { email, password }, onSuccess, onFail);
};

export const registerUser = function ({ email, password }, onSuccess, onFail) {
    console.log('SUBMIT', { email, password }, onSuccess, onFail);
};

export const editProfile = function ({
    firstName, lastName, email, phone,
}, onSuccess, onFail) {
    console.log('SUBMIT', {
        firstName, lastName, email, phone,
    }, onSuccess, onFail);
};
