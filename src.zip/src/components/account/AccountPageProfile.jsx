// react
import React, { useState } from 'react';

// third-party
import { Helmet } from 'react-helmet-async';

// data stubs
import theme from '../../data/theme';

// apis
import { editProfile } from '../../api/auth';

export default function AccountPageProfile() {
    const [user, setUser] = useState({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
    });

    function onChange(e) {
        setUser((prev) => ({
            ...prev,
            [e.target.name]: e.target.value,
        }));
    }

    function submit(e) {
        e.preventDefault();
        console.log('event: ', user);
        const {
            firstName, lastName, email, phone,
        } = user;
        editProfile({
            firstName, lastName, email, phone,
        }, (success) => { console.log(success); }, (fail) => { console.log(fail, 'fail'); });
    }

    return (
        <div className="card">
            <Helmet>
                <title>{`Profile — ${theme.name}`}</title>
            </Helmet>

            <div className="card-header">
                <h5>Edit Profile</h5>
            </div>
            <div className="card-divider" />
            <div className="card-body">
                <div className="row no-gutters">
                    <div className="col-12 col-lg-7 col-xl-6">
                        <div className="form-group">
                            <label htmlFor="profile-first-name">First Name</label>
                            <input
                                id="profile-first-name"
                                type="text"
                                className="form-control"
                                placeholder="First Name"
                                name="firstName"
                                value={user.firstName}
                                onChange={onChange}
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="profile-last-name">Last Name</label>
                            <input
                                id="profile-last-name"
                                type="text"
                                className="form-control"
                                placeholder="Last Name"
                                name="lastName"
                                value={user.lastName}
                                onChange={onChange}
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="profile-email">Email Address</label>
                            <input
                                id="profile-email"
                                type="email"
                                className="form-control"
                                placeholder="Email Address"
                                name="email"
                                value={user.email}
                                onChange={onChange}
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="profile-phone">Phone Number</label>
                            <input
                                id="profile-phone"
                                type="text"
                                className="form-control"
                                placeholder="Phone Number"
                                name="phone"
                                value={user.phone}
                                onChange={onChange}
                            />
                        </div>

                        <div className="form-group mt-5 mb-0">
                            <button onClick={submit} type="button" className="btn btn-primary">Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
