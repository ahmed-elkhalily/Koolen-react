// react
import React, { useState, useEffect } from 'react';

// third-party
import { Helmet } from 'react-helmet-async';

// data stubs
import theme from '../../data/theme';

// apis
import {
    getCountry, getStates, getCities, addNewAddress,
} from '../../api/addresses';

// components
import { toastError, toastSuccess } from '../toast/toastComponent';

export default function AccountPageEditAddress() {
    const [address, setAddress] = useState({
    });
    const [countries, setCountries] = useState([]);
    const [selectedCountry, setSelectedCountry] = useState(null);
    const [states, setStates] = useState([]);
    const [selectedState, setSelectedState] = useState(null);
    const [cities, setCities] = useState([]);
    const [selectedCity, setSelectedCity] = useState(null);
    const [postalCode, setPostalCode] = useState(null);
    const [phone, setPhone] = useState(null);
    console.log(selectedCountry);

    useEffect(() => {
        getCountry((success) => {
            if (success.success) {
                setCountries(success.data);
                setSelectedCountry(success.data[0].id);
            } else toastError(success);
        }, (fail) => toastError(fail));
    }, []);

    useEffect(() => {
        if (selectedCountry) {
            getCities(selectedCountry, (success) => {
                if (success.success) {
                    setCities(success.data);
                } else toastError(success);
            }, (fail) => toastError(fail));
        } else {
            setCities([]);
            setSelectedCity(null);
        }
    }, [selectedCountry]);

    useEffect(() => {
        if (selectedCity) {
            getStates(selectedCity, (success) => {
                if (success.success) {
                    setStates(success.data);
                } else toastError(success);
            }, (fail) => toastError(fail));
        } else {
            setStates([]);
            setSelectedState(null);
        }
    }, [selectedCity]);

    function submitNewAddress() {
        addNewAddress({
            address: address.address,
            city: address.city,
            postalCode: address.postalCode,
            state: address.state,
            phone: address.phone,
            name: address.name,
            country: address.country,
        }, (success) => {
            if (success.success) {
                toastSuccess(success);
            } else {
                toastError(success);
            }
        }, (fail) => {
            toastError(fail);
        });
    }

    console.log('selected country: ', selectedCountry);

    return (

        <div className="card">
            <Helmet>
                <title>{`Edit Address — ${theme.name}`}</title>
            </Helmet>

            <div className="card-header">
                <h5>Edit Address</h5>
            </div>
            <div className="card-divider" />
            <div className="card-body">
                <div className="row no-gutters">
                    <div className="col-12 col-lg-10 col-xl-8">
                        <div className="form-group">
                            <label htmlFor="checkout-country">Country</label>
                            <select
                                autoComplete="off"
                                id="checkout-country"
                                vlaue={selectedCountry}
                                onChange={(e) => setSelectedCountry(e.target.value)}
                                className="form-control form-control-select2"
                            >
                                {
                                    countries.map(({ id, name }) => (
                                        <option key={id} value={id}>
                                            {name}
                                        </option>
                                    ))
                                }
                            </select>
                        </div>
                        <div className="form-group">
                            <label htmlFor="checkout-street-address">Address</label>
                            <input
                                type="text"
                                className="form-control"
                                id="checkout-street-address"
                                placeholder="Street Address"
                                name="address"
                                vlaue={address}
                                onChange={setAddress}
                                autoComplete="off"
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="checkout-city">Town / City</label>
                            <select
                                autoComplete="off"
                                id="checkout-country"
                                vlaue={selectedCity}
                                onChange={(e) => setSelectedCity(e.target.value)}
                                className="form-control form-control-select2"
                            >
                                {
                                    cities.map(({ id, name }) => (
                                        <option key={id} value={id}>
                                            {name}
                                        </option>
                                    ))
                                }
                            </select>
                        </div>
                        <div className="form-group">
                            <label htmlFor="checkout-state">State</label>
                            <select
                                autoComplete="off"
                                id="checkout-country"
                                vlaue={selectedState}
                                onChange={(e) => setSelectedState(e.target.value)}
                                className="form-control form-control-select2"
                            >
                                {
                                    states.map(({ id, name }) => (
                                        <option key={id} value={id}>
                                            {name}
                                        </option>
                                    ))
                                }
                            </select>
                        </div>
                        <div className="form-group">
                            <label htmlFor="checkout-postcode">Postcode / ZIP</label>
                            <input
                                type="text"
                                className="form-control"
                                id="checkout-postcode"
                                name="postalCode"
                                placeholder="Postcode / ZIP"
                                value={postalCode}
                                onChange={setPostalCode}
                                autoComplete="off"
                            />
                        </div>

                        <div className="form-group ">
                            <label htmlFor="checkout-phone">Phone</label>
                            <input
                                type="text"
                                className="form-control"
                                id="checkout-phone"
                                placeholder="Phone"
                                name="phone"
                                value={phone}
                                onChange={setPhone}
                                autoComplete="off"
                            />
                        </div>

                        <div className="form-group mt-3 mb-0">
                            <button onClick={submitNewAddress} className="btn btn-primary" type="button">Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
