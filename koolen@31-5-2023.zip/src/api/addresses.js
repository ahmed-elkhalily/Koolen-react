import { getRequest, postRequest } from './network';

export function getCountry(onSuccess, onFail) {
    const path = '/api/v1/all-countries';
    getRequest(path, onSuccess, onFail);
}

export function getStates(id, onSuccess, onFail) {
    const path = `/api/v1/states/${id}`;
    getRequest(path, onSuccess, onFail);
}

export function getCities(id, onSuccess, onFail) {
    const path = `/api/v1/cities/${id}`;
    getRequest(path, onSuccess, onFail);
}

export function addNewAddress({
    address, country, city, postalCode, state, phone, defaultAddress, name,
}, onSuccess, onFail) {
    const path = '/api/v1/user/address/create';
    const data = {
        address, country, state, city, postal_code: postalCode, phone, default: defaultAddress, name,
    };
    postRequest(path, data, onSuccess, onFail);
}

export function editAddress(id, {
    address, country, city, postalCode, state, phone, defaultAddress,
}, onSuccess, onFail) {
    const path = '/api/v1/user/address/update';
    const data = {
        id, address, country, state, city, postal_code: postalCode, phone, default: defaultAddress,
    };
    postRequest(path, data, onSuccess, onFail);
}
